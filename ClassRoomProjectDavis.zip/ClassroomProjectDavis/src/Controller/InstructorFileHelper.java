package Controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import Model.Instructor;

public class InstructorFileHelper {

	String nameOfFile = "instructors.txt";
	File instructorsList = new File(nameOfFile);

	public boolean doesAFileExist() {

		if (instructorsList.exists()) {
			return true;
		} else {
			return false;
		}
	}

	public ArrayList<?> readFile() {
		ArrayList<Instructor> allInstructors = new ArrayList<Instructor>();

		Scanner fileIn;
		try {
			fileIn = new Scanner(instructorsList);

			while (fileIn.hasNextLine()) {
				String value = fileIn.nextLine();
				String[] parts = value.split(",");
				Instructor instructor = new Instructor(parts[0], parts[1], parts[2]);
				allInstructors.add(instructor);
			}
			fileIn.close();

		} catch (FileNotFoundException e) {
			//
		}

		return allInstructors;

	}

	public boolean writeFile(ArrayList<?> list) {

		ArrayList<Instructor> instructorsToWrite = (ArrayList<Instructor>)(list);

		try {
			PrintWriter instructorFile = new PrintWriter(nameOfFile);
			for (Instructor i : instructorsToWrite) {
				StringBuilder sb = new StringBuilder();
				sb.append(i.getFirstName() + "," + i.getLastName() + "," + i.getEmail() + "," + i.getClass());
			}
			
			instructorFile.close();

		} catch (FileNotFoundException e) {
			return false;
		}
		return true;
	}


}
