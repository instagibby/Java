package Controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import Model.Classroom;
import Model.Course;
import Model.Instructor;

public class CourseFileHelper {

	String nameOfFile = "courses.txt";
	File coursesList = new File(nameOfFile);
	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("hh:mm:ss.zzz");

	public boolean doesAFileExist() {

		if (coursesList.exists()) {
			return true;
		} else {
			return false;
		}
	}

	public ArrayList<?> readFile() {
		ArrayList<Course> allCourses = new ArrayList<Course>();

		Scanner fileIn;
		try {
			fileIn = new Scanner(coursesList);

			while (fileIn.hasNextLine()) {
				String value = fileIn.nextLine();
				String[] parts = value.split(",");

				// Grabs the line that is dedicated to the instructor and makes a new Instructor
				// that is aTeacher and passes in the values
				String val1 = parts[4];
				String[] p1 = val1.split(",");

				Instructor aTeacher = new Instructor(p1[0], p1[2], p1[2]);

				// Grabs the line that is the classroom and splits it, making a new Classroom
				// that is aClassroom as passes in the values
				String val2 = parts[5];
				String[] p2 = val2.split(",");

				Classroom aClassroom = new Classroom(p2[0], p2[1], p2[2], p2[3], Integer.parseInt(p2[4]));

				Course course = new Course(parts[0], parts[1], LocalTime.parse(parts[2], formatter),
						LocalTime.parse(parts[3], formatter), aTeacher, aClassroom);
				allCourses.add(course);
			}
			fileIn.close();

		} catch (FileNotFoundException e) {
			//
		}

		return allCourses;

	}

	public boolean writeFile(ArrayList<?> list) {

		ArrayList<Course> coursesToWrite = (ArrayList<Course>) (list);

		try {
			PrintWriter courseFile = new PrintWriter(nameOfFile);
			for (Course c : coursesToWrite) {
				StringBuilder sb = new StringBuilder();
				sb.append(c.getCRN() + "," + c.getCourseName() + "," + c.getStartTime() + "," + c.getEndTime() + ","
						+ c.getTeacher() + "," + c.getLocation());
			}

			courseFile.close();

		} catch (FileNotFoundException e) {
			return false;
		}
		return true;
	}

}